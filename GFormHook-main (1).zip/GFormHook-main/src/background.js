import { API_BASE_URL, API_BASE_URL_CANDIDATES, MODEL_NAME, API_KEY } from "./config.js";

const MENU_ID_FILL_ALL = "gform-ai-autofill";
const MENU_ID_FILL_UNANSWERED = "gform-ai-fill-unanswered";
const MENU_ID_REVIEW_ANSWERED = "gform-ai-review-answered";
const MENU_ID_ANSWER_THIS_CARD = "gform-ai-answer-this-card";
const hasContextCardByTab = new Map();
const ANSWER_CACHE_PREFIX = "answer_cache:";
const API_TIMEOUT_MS = 25000;
const AI_BATCH_SIZE = 5;

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: MENU_ID_FILL_ALL,
    title: "AI Auto-fill Google Form",
    contexts: ["all"],
    documentUrlPatterns: ["https://docs.google.com/forms/*"]
  });
  chrome.contextMenus.create({
    id: MENU_ID_FILL_UNANSWERED,
    title: "AI Chọn câu chưa chọn",
    contexts: ["all"],
    documentUrlPatterns: ["https://docs.google.com/forms/*"]
  });
  chrome.contextMenus.create({
    id: MENU_ID_REVIEW_ANSWERED,
    title: "AI Check lại đáp án đã chọn",
    contexts: ["all"],
    documentUrlPatterns: ["https://docs.google.com/forms/*"]
  });
  chrome.contextMenus.create({
    id: MENU_ID_ANSWER_THIS_CARD,
    title: "AI Trả lời card này",
    contexts: ["all"],
    documentUrlPatterns: ["https://docs.google.com/forms/*"],
    visible: false
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "CONTEXT_MENU_CARD_STATE") {
    const tabId = sender?.tab?.id;
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    const hasCard = Boolean(message.hasCard);
    hasContextCardByTab.set(tabId, hasCard);
    chrome.contextMenus.update(MENU_ID_ANSWER_THIS_CARD, { visible: hasCard }, () => {
      chrome.contextMenus.refresh();
      sendResponse({ ok: true });
    });
    return true;
  }
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  const mode = resolveMode(info.menuItemId);
  if (!mode) return;
  await runAutofill(tab.id, tab.url || "", mode);
});

chrome.commands.onCommand.addListener(async (command) => {
  let mode = null;
  if (command === "autofill_unanswered") mode = "fill_unanswered";
  if (command === "autofill_all") mode = "fill_all";
  if (!mode) return;

  const tab = await getActiveTab();
  if (!tab?.id) return;

  if (!isGoogleFormUrl(tab.url || "")) {
    console.log("[GFormHook][BG] Hotkey ignored: active tab is not Google Form", { url: tab.url });
    return;
  }

  await runAutofill(tab.id, tab.url || "", mode);
});

async function runAutofill(tabId, tabUrl, mode) {
  try {
    console.log("[GFormHook][BG] Start:", { tabId, url: tabUrl, mode });

    const formDataResponse = await sendMessage(tabId, { type: "COLLECT_FORM_DATA" });
    const allQuestions = formDataResponse?.questions ?? [];
    let questions = filterQuestionsByMode(allQuestions, mode);
    if (mode === "answer_context_card") {
      const target = await sendMessage(tabId, { type: "GET_LAST_CONTEXT_QUESTION_ID" });
      const targetId = target?.questionId;
      console.log("[GFormHook][BG] Context card target id:", targetId);
      questions = targetId ? allQuestions.filter((q) => q.id === targetId) : [];
    }
    console.log("[GFormHook][BG] Collected questions:", questions.length, questions);

    if (questions.length === 0) {
      console.log("[GFormHook][BG] Stop:", emptyMessageByMode(mode));
      return;
    }

    const shouldUseBatch = mode === "fill_all" || mode === "fill_unanswered";
    const result = shouldUseBatch
      ? await processQuestionsBatch(tabId, tabUrl, allQuestions, questions, mode)
      : await processQuestionsSequential(tabId, questions, mode);
    const filled = result.filled;
    const skipped = result.skipped;

    console.log("[GFormHook][BG] Done:", {
      total: questions.length,
      filled,
      skipped
    });
  } catch (error) {
    console.error("[GFormHook] Autofill failed:", error);
  }
}

function resolveMode(menuItemId) {
  if (menuItemId === MENU_ID_FILL_ALL) return "fill_all";
  if (menuItemId === MENU_ID_FILL_UNANSWERED) return "fill_unanswered";
  if (menuItemId === MENU_ID_REVIEW_ANSWERED) return "review_answered";
  if (menuItemId === MENU_ID_ANSWER_THIS_CARD) return "answer_context_card";
  return null;
}

function filterQuestionsByMode(questions, mode) {
  if (mode === "fill_unanswered") {
    return questions.filter((q) => !q.selectedOptionText);
  }
  if (mode === "review_answered") {
    return questions.filter((q) => Boolean(q.selectedOptionText));
  }
  if (mode === "answer_context_card") {
    return questions;
  }
  return questions;
}

function emptyMessageByMode(mode) {
  if (mode === "fill_unanswered") return "No unanswered single-choice questions found.";
  if (mode === "review_answered") return "No answered single-choice questions to review.";
  if (mode === "answer_context_card") return "No supported question found on selected card.";
  return "No supported single-choice questions found.";
}

async function fetchAiAnswerForQuestion(question) {
  const systemPrompt =
    "You are an assistant that solves multiple-choice questions. " +
    "Return only strict JSON, no markdown, no explanation. " +
    "Only choose from provided options. If unsure, set confidence below 0.75.";

  const userPrompt = [
    "Task (VI): Chọn đáp án đúng nhất cho câu hỏi trắc nghiệm một đáp án dưới đây.",
    "Task (EN): Select the best answer for the single-choice question below.",
    "Output JSON schema exactly:",
    '{"answer":{"id":"string","selectedOptionText":"string","confidence":0.0}}',
    "Rules:",
    "1) Keep the same id from input question.",
    "2) selectedOptionText must exactly match one option text from input.",
    "3) If uncertain, still return best guess but with low confidence.",
    "",
    "Input:",
    JSON.stringify({ question })
  ].join("\n");

  const payload = {
    model: MODEL_NAME,
    temperature: 0,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]
  };
  console.log("[GFormHook][BG] API request payload:", payload);

  const data = await requestChatCompletions(payload, "single");
  console.log("[GFormHook][BG] API raw response:", data);
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI response missing message content");

  let parsed;
  try {
    parsed = JSON.parse(content);
  } catch (error) {
    throw new Error(`Failed to parse AI JSON: ${error.message}`);
  }

  if (!parsed || !parsed.answer || !parsed.answer.id) {
    throw new Error("AI JSON does not include answer object");
  }

  return parsed.answer;
}

async function processQuestionsSequential(tabId, questions, mode) {
  let filled = 0;
  let skipped = 0;

  for (let i = 0; i < questions.length; i += 1) {
    const question = questions[i];
    console.log(`[GFormHook][BG] Progress ${i + 1}/${questions.length}`, {
      id: question.id,
      question: question.questionText
    });

    const aiAnswer = await fetchAiAnswerForQuestion(question);
    console.log("[GFormHook][BG] AI answer:", aiAnswer);
    const fillResult = await sendMessage(tabId, {
      type: "APPLY_ONE_ANSWER",
      answer: aiAnswer,
      mode
    });
    console.log("[GFormHook][BG] Fill result:", fillResult);

    if (fillResult?.filled) {
      filled += 1;
    } else {
      skipped += 1;
    }
  }

  return { filled, skipped };
}

async function processQuestionsBatch(tabId, formUrl, allQuestions, targetQuestions, mode) {
  const cacheKey = buildCacheKey(formUrl, allQuestions);
  const cached = await getCache(cacheKey);
  const byId = new Map();
  const cachedAnswers = Array.isArray(cached?.answers) ? cached.answers : [];
  for (const answer of cachedAnswers) {
    if (answer?.id) byId.set(answer.id, answer);
  }
  console.log("[GFormHook][BG] Cache status", {
    cachedAnswerCount: byId.size,
    totalTargets: targetQuestions.length,
    batchSize: AI_BATCH_SIZE
  });

  let filled = 0;
  let skipped = 0;
  for (let start = 0; start < targetQuestions.length; start += AI_BATCH_SIZE) {
    const chunk = targetQuestions.slice(start, start + AI_BATCH_SIZE);
    const missing = chunk.filter((q) => !byId.get(q.id));
    const chunkNo = Math.floor(start / AI_BATCH_SIZE) + 1;
    const totalChunks = Math.ceil(targetQuestions.length / AI_BATCH_SIZE);
    console.log(`[GFormHook][BG] Fill chunk ${chunkNo}/${totalChunks}`, {
      from: start + 1,
      to: start + chunk.length,
      missingForAi: missing.length
    });

    if (missing.length > 0) {
      const aiAnswers = await fetchAiAnswersForQuestions(missing);
      const received = aiAnswers.answers ?? [];
      for (const answer of received) {
        if (answer?.id) byId.set(answer.id, answer);
      }
      await setCache(cacheKey, {
        createdAt: Date.now(),
        questionCount: allQuestions.length,
        answers: Array.from(byId.values())
      });
    }

    for (let i = 0; i < chunk.length; i += 1) {
      const question = chunk[i];
      const answer = byId.get(question.id);
      console.log(`[GFormHook][BG] Progress ${start + i + 1}/${targetQuestions.length}`, {
        id: question.id,
        fromCache: Boolean(answer)
      });
      const fillResult = await sendMessage(tabId, {
        type: "APPLY_ONE_ANSWER",
        answer,
        mode
      });
      console.log("[GFormHook][BG] Fill result:", fillResult);
      if (fillResult?.filled) {
        filled += 1;
      } else {
        skipped += 1;
      }
    }
  }

  return { filled, skipped };
}

async function fetchAiAnswersForQuestions(questions) {
  const systemPrompt =
    "You are an assistant that solves multiple-choice questions. " +
    "Return only strict JSON, no markdown, no explanation. " +
    "Only choose from provided options. If unsure, set confidence below 0.75.";

  const userPrompt = [
    "Task (VI): Chọn đáp án đúng nhất cho từng câu trắc nghiệm một đáp án.",
    "Task (EN): Select the best answer for each single-choice multiple-choice question.",
    "Output JSON schema exactly:",
    '{"answers":[{"id":"string","selectedOptionText":"string","confidence":0.0}]}',
    "Rules:",
    "1) Keep the same id from input.",
    "2) selectedOptionText must exactly match one option text from input.",
    "3) If uncertain, still return best guess but with low confidence.",
    "",
    "Input:",
    JSON.stringify({ questions })
  ].join("\n");

  const payload = {
    model: MODEL_NAME,
    temperature: 0,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt }
    ]
  };
  console.log("[GFormHook][BG] Batch API request payload:", payload);

  const data = await requestChatCompletions(payload, "batch");
  console.log("[GFormHook][BG] Batch API raw response:", data);
  const content = data?.choices?.[0]?.message?.content;
  if (!content) throw new Error("AI response missing message content");

  let parsed;
  try {
    parsed = JSON.parse(content);
  } catch (error) {
    throw new Error(`Failed to parse AI JSON: ${error.message}`);
  }

  if (!parsed || !Array.isArray(parsed.answers)) {
    throw new Error("AI JSON does not include answers[]");
  }

  return parsed;
}

async function requestChatCompletions(payload, modeLabel) {
  const candidates = Array.from(
    new Set([API_BASE_URL, ...(Array.isArray(API_BASE_URL_CANDIDATES) ? API_BASE_URL_CANDIDATES : [])])
  );
  const attempts = [];

  for (const baseUrl of candidates) {
    const endpoint = `${baseUrl}/chat/completions`;
    const startMs = Date.now();
    console.log(`[GFormHook][BG][NET] ${modeLabel} try`, { endpoint });

    try {
      const response = await fetchWithTimeout(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${API_KEY}`
        },
        body: JSON.stringify(payload)
      });

      const elapsedMs = Date.now() - startMs;
      if (!response.ok) {
        const text = await response.text();
        const failure = {
          endpoint,
          elapsedMs,
          type: "http_error",
          status: response.status,
          statusText: response.statusText,
          bodyPreview: text.slice(0, 500)
        };
        attempts.push(failure);
        console.error("[GFormHook][BG][NET] HTTP error:", failure);
        continue;
      }

      const data = await response.json();
      console.log("[GFormHook][BG][NET] success:", { endpoint, elapsedMs });
      return data;
    } catch (error) {
      const elapsedMs = Date.now() - startMs;
      const failure = {
        endpoint,
        elapsedMs,
        type: "network_error",
        errorName: error?.name || "Error",
        errorMessage: error?.message || String(error),
        probableCause: classifyNetworkError(error)
      };
      attempts.push(failure);
      console.error("[GFormHook][BG][NET] Network error:", failure);
    }
  }

  throw new Error(
    `[NetworkFailed] All API endpoints failed. Attempts=${JSON.stringify(attempts)}`
  );
}

function fetchWithTimeout(url, options) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
  return fetch(url, {
    ...options,
    signal: controller.signal
  }).finally(() => clearTimeout(timer));
}

function classifyNetworkError(error) {
  const name = error?.name || "";
  const message = String(error?.message || "").toLowerCase();
  if (name === "AbortError") return "timeout_or_hang";
  if (message.includes("failed to fetch")) return "connection_refused_or_cors_or_dns";
  if (message.includes("ssl") || message.includes("tls")) return "tls_certificate_error";
  if (message.includes("network")) return "general_network_error";
  return "unknown";
}

function buildCacheKey(formUrl, questions) {
  const signatureQuestions = questions.map((q) => ({
    questionText: q.questionText,
    options: q.options
  }));
  const raw = JSON.stringify({
    formUrl: normalizeUrl(formUrl),
    questions: signatureQuestions
  });
  return `${ANSWER_CACHE_PREFIX}${simpleHash(raw)}`;
}

function normalizeUrl(url) {
  if (!url) return "";
  return url.split("?")[0];
}

function isGoogleFormUrl(url) {
  return normalizeUrl(url).startsWith("https://docs.google.com/forms/");
}

function simpleHash(input) {
  let hash = 0;
  for (let i = 0; i < input.length; i += 1) {
    hash = (hash << 5) - hash + input.charCodeAt(i);
    hash |= 0;
  }
  return `h${Math.abs(hash)}`;
}

function getStorageLocal(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(result);
    });
  });
}

function setStorageLocal(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve();
    });
  });
}

async function getCache(cacheKey) {
  const data = await getStorageLocal([cacheKey]);
  return data[cacheKey] || null;
}

async function setCache(cacheKey, payload) {
  await setStorageLocal({ [cacheKey]: payload });
}

function sendMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(response);
    });
  });
}

function getActiveTab() {
  return new Promise((resolve, reject) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const runtimeError = chrome.runtime.lastError;
      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }
      resolve(tabs?.[0] || null);
    });
  });
}
