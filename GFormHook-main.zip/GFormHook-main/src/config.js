export const API_BASE_URL = "http://180.93.113.46:20128/v1";
export const API_BASE_URL_CANDIDATES = [
  "http://180.93.113.46:20128/v1"
];
export const MODEL_NAME = "cx/gpt-5.3-codex-xhigh";
export const API_KEY = "sk-fc0b27cf63ed9f2a-c1ap6w-c0a35d1e";

export const CONFIDENCE_THRESHOLD = 0.75;
