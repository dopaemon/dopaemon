# GForm AI Autofill (Chrome Extension)

Chrome extension Manifest V3 to auto-fill Google Form single-choice questions using a local AI API.

## Fixed config (v1)

- API base URL: `http://localhost:20128/v1`
- Model: `cx/gpt-5.3-codex-xhigh`
- API key: hard-coded in `src/config.js`

## Features

- Trigger from context menu on Google Form pages with 4 actions:
  - `AI Auto-fill Google Form`: fill all supported questions.
  - `AI Chọn câu chưa chọn`: only fill unanswered questions.
  - `AI Check lại đáp án đã chọn`: review already-answered questions and adjust by AI (calls AI per question).
  - `AI Trả lời card này`: right-click on one question card and answer only that card.
- Supports single-choice multiple-choice questions (radio) only.
- Sends question text + options to AI.
- Fills answers with confidence >= `0.75`.
- Skips low-confidence or unmatched answers.
- Does **not** submit the form automatically.
- Progress is shown in console logs (`[GFormHook][BG]`, `[GFormHook][CS]`), no on-page progress banner.
- Cost-saving behavior:
  - `AI Auto-fill Google Form` and `AI Chọn câu chưa chọn` use one batch AI call for the whole form, then cache answers in `chrome.storage.local`.
  - Later runs reuse cache if the same form/question set is detected.
  - `AI Check lại đáp án đã chọn` and `AI Trả lời card này` call AI one-by-one.

## Load extension

1. Open `chrome://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder: `GFormHook`.

## Usage

1. Open a Google Form page in Chrome (`https://docs.google.com/forms/*`).
2. Right click anywhere in page.
3. Click one action:
   - `AI Auto-fill Google Form`
   - `AI Chọn câu chưa chọn`
   - `AI Check lại đáp án đã chọn`
4. Open console logs to track progress/results.

## Notes

- This extension relies on current Google Form DOM and may need selector updates if Google changes UI structure.
- Hard-coded key is insecure for distributed builds; keep local-only unless replaced with secure storage.
