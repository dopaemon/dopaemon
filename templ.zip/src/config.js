export const API_BASE_URL = "http://localhost:20128/v1";
export const MODEL_NAME = "cx/gpt-5.3-codex-xhigh";
export const API_KEY = "sk-e212df3760c41aaa-ikczlj-a6c05162";

export const CONFIDENCE_THRESHOLD = 0.75;
