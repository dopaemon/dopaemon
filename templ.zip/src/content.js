const CONFIDENCE_THRESHOLD = 0.75;
let lastContextQuestionId = "";

document.addEventListener(
  "contextmenu",
  (event) => {
    const questionItem = findQuestionItemFromNode(event.target);
    if (questionItem) {
      ensureQuestionIds();
      lastContextQuestionId = questionItem.dataset.gformAiQuestionId || "";
      console.log("[GFormHook][CS] contextmenu on question:", lastContextQuestionId);
      notifyContextMenuCardState(true);
      return;
    }
    lastContextQuestionId = "";
    notifyContextMenuCardState(false);
  },
  true
);

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  console.log("[GFormHook][CS] Received message:", message?.type, message);

  if (message?.type === "COLLECT_FORM_DATA") {
    const questions = collectSingleChoiceQuestions();
    console.log("[GFormHook][CS] collect result:", questions.length, questions);
    sendResponse({ questions });
    return;
  }

  if (message?.type === "APPLY_AI_ANSWERS") {
    const result = applyAnswers(message.answers ?? []);
    sendResponse(result);
    return;
  }

  if (message?.type === "APPLY_ONE_ANSWER") {
    const result = applyOneAnswer(message.answer, message.mode);
    sendResponse(result);
    return;
  }

  if (message?.type === "SHOW_STATUS") {
    showStatus(message.message ?? "", message.level ?? "info");
    sendResponse({ ok: true });
    return;
  }

  if (message?.type === "GET_LAST_CONTEXT_QUESTION_ID") {
    sendResponse({ questionId: lastContextQuestionId });
  }
});

function collectSingleChoiceQuestions() {
  ensureQuestionIds();
  const listItems = Array.from(document.querySelectorAll('[role="listitem"]'));
  console.log("[GFormHook][CS] list items found:", listItems.length);
  const questions = [];

  for (let i = 0; i < listItems.length; i += 1) {
    const item = listItems[i];
    const radioNodes = Array.from(item.querySelectorAll('[role="radio"]'));
    if (radioNodes.length < 2) continue;

    const questionText = extractQuestionText(item);
    if (!questionText) continue;

    const options = [];
    const optionSet = new Set();

    for (const radioNode of radioNodes) {
      const optionText = extractOptionText(radioNode);
      if (!optionText || optionSet.has(optionText)) continue;
      optionSet.add(optionText);
      options.push(optionText);
    }

    if (options.length < 2) continue;

    const questionId = item.dataset.gformAiQuestionId || `q_${i + 1}`;
    item.dataset.gformAiQuestionId = questionId;
    console.log("[GFormHook][CS] mapped question:", questionId, questionText, options);
    questions.push({
      id: questionId,
      questionText,
      options,
      selectedOptionText: getSelectedOptionText(item)
    });
  }

  return questions;
}

function applyAnswers(answers) {
  const byId = new Map();
  for (const answer of answers) {
    if (answer?.id) byId.set(answer.id, answer);
  }

  const listItems = Array.from(document.querySelectorAll('[role="listitem"]'));
  let filledCount = 0;
  let skippedCount = 0;

  for (const item of listItems) {
    const questionId = item.dataset.gformAiQuestionId;
    if (!questionId) continue;

    const answer = byId.get(questionId);
    if (!answer || !isValidConfidence(answer.confidence)) {
      skippedCount += 1;
      continue;
    }

    const targetOption = normalizeText(answer.selectedOptionText);
    if (!targetOption) {
      skippedCount += 1;
      continue;
    }

    const radios = Array.from(item.querySelectorAll('[role="radio"]'));
    const matched = radios.find((node) => normalizeText(extractOptionText(node)) === targetOption);

    if (!matched) {
      skippedCount += 1;
      continue;
    }

    matched.click();
    filledCount += 1;
  }

  return { filledCount, skippedCount };
}

function applyOneAnswer(answer, mode) {
  if (!answer?.id || !isValidConfidence(answer.confidence)) {
    console.log("[GFormHook][CS] skip applyOneAnswer: invalid answer/confidence", answer);
    return { filled: false };
  }

  const targetItem = document.querySelector(`[data-gform-ai-question-id="${answer.id}"]`);
  if (!targetItem) {
    console.log("[GFormHook][CS] skip applyOneAnswer: question node not found", answer.id);
    return { filled: false };
  }

  const targetOption = normalizeText(answer.selectedOptionText);
  if (!targetOption) {
    console.log("[GFormHook][CS] skip applyOneAnswer: empty target option", answer);
    return { filled: false };
  }

  const radios = Array.from(targetItem.querySelectorAll('[role="radio"]'));
  if (mode === "fill_unanswered") {
    const currentSelection = getSelectedOptionText(targetItem);
    if (currentSelection) {
      console.log("[GFormHook][CS] skip applyOneAnswer: already selected in fill_unanswered mode", {
        id: answer.id,
        currentSelection
      });
      return { filled: false };
    }
  }

  const matched = radios.find((node) => normalizeText(extractOptionText(node)) === targetOption);
  if (!matched) {
    const availableOptions = radios.map((node) => extractOptionText(node));
    console.log("[GFormHook][CS] skip applyOneAnswer: option not matched", {
      answer,
      availableOptions
    });
    return { filled: false };
  }

  matched.click();
  console.log("[GFormHook][CS] clicked:", answer.id, targetOption);
  return { filled: true };
}

function getSelectedOptionText(questionItem) {
  const radios = Array.from(questionItem.querySelectorAll('[role="radio"]'));
  const selectedNode = radios.find((node) => {
    const checked = node.getAttribute("aria-checked");
    return checked === "true";
  });
  if (!selectedNode) return "";
  return normalizeText(extractOptionText(selectedNode));
}

function ensureQuestionIds() {
  const listItems = Array.from(document.querySelectorAll('[role="listitem"]'));
  for (let i = 0; i < listItems.length; i += 1) {
    const item = listItems[i];
    if (!item.dataset.gformAiQuestionId) {
      item.dataset.gformAiQuestionId = `q_${i + 1}`;
    }
  }
}

function findQuestionItemFromNode(node) {
  if (!node || !(node instanceof Element)) return null;
  return node.closest('[role="listitem"]');
}

function notifyContextMenuCardState(hasCard) {
  chrome.runtime.sendMessage({
    type: "CONTEXT_MENU_CARD_STATE",
    hasCard
  });
}

function extractQuestionText(container) {
  const selectors = [
    '[role="heading"]',
    '.M7eMe',
    '.HoXoMd',
    '.z12JJ',
    '.M4DNQ'
  ];

  for (const selector of selectors) {
    const node = container.querySelector(selector);
    const text = normalizeText(node?.textContent || "");
    if (text) return text;
  }

  return "";
}

function extractOptionText(radioNode) {
  const aria = normalizeText(radioNode.getAttribute("aria-label") || "");
  if (aria) return aria;

  const labelNode = radioNode.closest('label, [role="radio"]') || radioNode.parentElement;
  const text = normalizeText(labelNode?.textContent || "");
  return text;
}

function isValidConfidence(value) {
  if (typeof value !== "number") return false;
  return value >= CONFIDENCE_THRESHOLD;
}

function normalizeText(text) {
  return (text || "").replace(/\s+/g, " ").trim();
}

function showStatus(message, level) {
  const existing = document.getElementById("gform-ai-autofill-status");
  if (existing) existing.remove();

  const banner = document.createElement("div");
  banner.id = "gform-ai-autofill-status";
  banner.textContent = message;

  const colorByLevel = {
    info: "#0b57d0",
    success: "#137333",
    warn: "#b06000",
    error: "#c5221f"
  };

  banner.style.position = "fixed";
  banner.style.top = "16px";
  banner.style.right = "16px";
  banner.style.zIndex = "999999";
  banner.style.background = colorByLevel[level] || colorByLevel.info;
  banner.style.color = "#fff";
  banner.style.padding = "10px 14px";
  banner.style.borderRadius = "8px";
  banner.style.fontFamily = "Arial, sans-serif";
  banner.style.fontSize = "13px";
  banner.style.boxShadow = "0 6px 16px rgba(0,0,0,0.2)";

  document.body.appendChild(banner);
  setTimeout(() => {
    banner.remove();
  }, 4200);
}
