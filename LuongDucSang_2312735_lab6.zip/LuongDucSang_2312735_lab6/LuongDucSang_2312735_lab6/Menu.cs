﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuongDucSang_2312735_lab6
{
    internal class Menu
    {
        DanhSachAnPham dsap = new DanhSachAnPham();
        public enum MenuDSAP {
            Thoat_chuong_trinh,
            Doc_DS_an_pham_tu_file,
            Xuat_DS_an_pham_co_can_le,
            Tim_an_pham_co_gia_lon_nhat,
            Tim_DS_an_pham_thuoc_nha_xuat_ban_x,
            Hien_thi_cac_an_pham_theo_gia,
            Tinh_tong_gia_tien_cua_DS_an_pham,
            Sap_xep_DS_an_pham_giam_theo_ten_giam_theo_gia,//(su dung delegate)
            Sap_xep_DS_an_pham_giam_theo_ten_tang_theo_gia,//(sử dụng IComparer)
            Tim_cac_an_pham_co_gia_thap_nhat,
            Xoa_all_co_an_pham_thap_nhat,
            chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i
        }   
        public Menu()
        {
            dsap = new DanhSachAnPham();
        }
        private void XuatMenu()
        {
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Thoat_chuong_trinh, MenuDSAP.Thoat_chuong_trinh);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Doc_DS_an_pham_tu_file, MenuDSAP.Doc_DS_an_pham_tu_file);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Xuat_DS_an_pham_co_can_le, MenuDSAP.Xuat_DS_an_pham_co_can_le);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Tim_an_pham_co_gia_lon_nhat, MenuDSAP.Tim_an_pham_co_gia_lon_nhat);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Tim_DS_an_pham_thuoc_nha_xuat_ban_x, MenuDSAP.Tim_DS_an_pham_thuoc_nha_xuat_ban_x);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Hien_thi_cac_an_pham_theo_gia, MenuDSAP.Hien_thi_cac_an_pham_theo_gia);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Tinh_tong_gia_tien_cua_DS_an_pham, MenuDSAP.Tinh_tong_gia_tien_cua_DS_an_pham);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_giam_theo_gia, MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_giam_theo_gia);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_tang_theo_gia, MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_tang_theo_gia);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Tim_cac_an_pham_co_gia_thap_nhat, MenuDSAP.Tim_cac_an_pham_co_gia_thap_nhat);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.Xoa_all_co_an_pham_thap_nhat, MenuDSAP.Xoa_all_co_an_pham_thap_nhat);
            Console.WriteLine("Nhap {0} de {1}", (int)MenuDSAP.chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i, MenuDSAP.chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i);
        }
        private MenuDSAP ChonMenu()
        {
            int chon = 0;
            do
            {
                Console.WriteLine("Nhap chon[{0}, {1}]", (int)MenuDSAP.Thoat_chuong_trinh, (int)MenuDSAP.chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i);
                chon = int.Parse(Console.ReadLine());
                if ((int)MenuDSAP.Thoat_chuong_trinh <= chon && chon <= (int)MenuDSAP.chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i)
                    break;
            } while (true);
            return (MenuDSAP)chon;
        }
        private void XuLyMenu(MenuDSAP chon)
        {
            switch (chon)
            {
                case MenuDSAP.Thoat_chuong_trinh:
                    break;
                case MenuDSAP.Doc_DS_an_pham_tu_file:
                    string path = Console.ReadLine();
                    dsap.NhapTuFile(path);
                    
                    break;
                case MenuDSAP.Xuat_DS_an_pham_co_can_le:
                    break;
                case MenuDSAP.Tim_an_pham_co_gia_lon_nhat:
                    break;
                case MenuDSAP.Tim_DS_an_pham_thuoc_nha_xuat_ban_x:
                    break;
                case MenuDSAP.Hien_thi_cac_an_pham_theo_gia:
                    break;
                case MenuDSAP.Tinh_tong_gia_tien_cua_DS_an_pham:
                    break;
                case MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_giam_theo_gia:
                    break;
                case MenuDSAP.Sap_xep_DS_an_pham_giam_theo_ten_tang_theo_gia:
                    break;
                case MenuDSAP.Tim_cac_an_pham_co_gia_thap_nhat:
                    break;
                case MenuDSAP.Xoa_all_co_an_pham_thap_nhat:
                    break;
                case MenuDSAP.chen_an_pham_vao_DS_an_pham_truoc_vi_tri_i:
                    break;
                    default: break;
            }
            Console.ReadKey();  
        }
        public void ChayChuongTrinh()
        {
            MenuDSAP chon;
            do
            {
                System.Console.Clear();
                XuatMenu();
                chon = ChonMenu();
                if (chon == MenuDSAP.Thoat_chuong_trinh)
                    break;
                XuLyMenu(chon);
            } while (true);
        }
    }
}
