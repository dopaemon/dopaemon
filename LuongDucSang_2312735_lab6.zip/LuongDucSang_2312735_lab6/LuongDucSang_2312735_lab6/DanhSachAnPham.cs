﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LuongDucSang_2312735_lab6
{
    delegate int SoSanh(object a, object b);
    enum KieuSapXep
    {
        TangTheoTen,
        TangTheoGia,
        GiamTheoNam
    }
    class DanhSachAnPham : List<IAnPham>, IComparer<IAnPham>
    {
        public List<IAnPham> collection = new List<IAnPham>();
        public int Compare(IAnPham x, IAnPham y)
        {
            if (kieu == KieuSapXep.TangTheoTen)
                return x.Ten.CompareTo(y.Ten);
            return x.GiaTien.CompareTo(y.GiaTien);
        }
        public void Them(IAnPham ap)
        {
            collection.Add(ap);
        }
        //public void NhapTuFile()
        //{
        //    string path = @"dsanpham.txt";
        //    StreamReader sr = new StreamReader(path);
        //    string str = "";
        //    while ((str = sr.ReadLine()) != null)
        //    {
        //        string[] s = str.Split(',');
        //        if (s[0] == "Sach")
        //            Them(new Sach(str));
        //        if (s[0] == "Bao")
        //            Them(new Bao(str));
        //        if (s[0] == "Tap chi")
        //            Them(new TapChi(str));
        //    }
        //}

        public void XuatDanhSach()
        {
            const int colWidth = 20;
            Console.WriteLine("{0,-20} {1,-20} {2,-20} {3,-20}", "Loai An Pham", "Ten", "Nha Xuat Ban", "Gia Tien");

            foreach (var item in collection)
            {
                string loaiAnPham = item.GetType().Name;
                Console.WriteLine("{0,-20} {1,-20} {2,-20} {3,-20}", loaiAnPham, item.Ten, item.NhaXuatBan, item.GiaTien);
            }
        }

        public IAnPham TimAnPhamCoGiaLonNhat()
        {
            if (collection.Count == 0) return null;

            IAnPham max = collection[0];
            foreach (var ap in collection)
            {
                if (ap.GiaTien > max.GiaTien)
                {
                    max = ap;
                }
            }
            return max;
        }

        public List<IAnPham> TimAnPhamTheoNhaXuatBan(string nhaXuatBan)
        {
            List<IAnPham> ketQua = new List<IAnPham>();
            foreach (var ap in collection)
            {
                if (ap.NhaXuatBan == nhaXuatBan)
                {
                    ketQua.Add(ap);
                }
            }
            return ketQua;
        }

        public List<IAnPham> TimDSAnPhamTheoGia(float giaTien)
        {
            List<IAnPham> dsap = new List<IAnPham>();
            foreach (var ap in collection)
            {
                if (ap.GiaTien == giaTien)
                {
                    dsap.Add(ap);
                }
            }
            return dsap;
        }

        public double TongGiaTienAnPham()
        {
            double count = 0.0;
            foreach (var ap in collection)
            {
                count = count + ap.GiaTien;
            }
            return count;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in collection)
            {
                sb.Append(item + "\n");
            }
            return sb.ToString();
        }
        public DanhSachAnPham TimAnPhamCoGiaCaoNhat()
        {
            float max = collection.Max(x => x.GiaTien);
            DanhSachAnPham kq = new DanhSachAnPham();
            kq.collection = collection.FindAll(x => x.GiaTien == max);
            return kq;
        }

        KieuSapXep kieu = KieuSapXep.TangTheoTen;
        public void SapXepTheoTen()
        {
            kieu = KieuSapXep.TangTheoTen;
            collection.Sort(this);
        }
        public void SapXepTheoGia()
        {
            kieu = KieuSapXep.TangTheoGia;
            collection.Sort(this);
        }


        public List<IAnPham> TimAnPhamCoGiaThapNhat()
        {
            if (this.Count == 0)
                return new List<IAnPham>(); // Trả về danh sách rỗng nếu danh sách ban đầu không có phần tử

            // Khởi tạo giá thấp nhất là giá của phần tử đầu tiên
            float giaThapNhat = this[0].GiaTien;

            // Duyệt qua từng phần tử trong danh sách để tìm giá thấp nhất
            foreach (var anPham in this)
            {
                if (anPham.GiaTien < giaThapNhat)
                {
                    giaThapNhat = anPham.GiaTien;
                }
            }

            // Tạo một danh sách mới để lưu trữ các ấn phẩm có giá thấp nhất
            List<IAnPham> anPhamGiaThapNhat = new List<IAnPham>();

            // Duyệt qua từng phần tử trong danh sách để thêm các ấn phẩm có giá thấp nhất vào danh sách mới
            foreach (var anPham in this)
            {
                if (anPham.GiaTien == giaThapNhat)
                {
                    anPhamGiaThapNhat.Add(anPham);
                }
            }

            return anPhamGiaThapNhat;
        }


        DanhSachAnPham TimAnPhamTheoGiaTien(int x)
        {
            DanhSachAnPham kq = new DanhSachAnPham();
            kq.collection = collection.FindAll(a => a.GiaTien == x);
            return kq;
        }
        public void SapXep(SoSanh ss)
        {
            for (int i = 0; i < this.collection.Count - 1; i++)
                for (int j = i + 1; j < this.collection.Count; j++)
                    if (ss(this.collection[i], this.collection[j]) == 1)
                    {
                        IAnPham a = this.collection[i];
                        this.collection[i] = this.collection[j];
                        this.collection[j] = a;
                    }
        }
        public void NhapTuFile()
        {
            try
            {
                using (StreamReader sr = new StreamReader("dsanpham.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] thongTin = line.Split(',');
                        if (thongTin.Length >= 5)
                        {
                            string loaiAnPham = thongTin[0].Trim();
                            string tenAnPham = thongTin[1].Trim();
                            string nhaXuatBan = thongTin[2].Trim();
                            float giaTien = float.Parse(thongTin[3].Trim());
                            string diachi = thongTin[4].Trim();

                            switch (loaiAnPham)
                            {
                                case "Sach":
                                    this.Them(new Sach(tenAnPham, nhaXuatBan, giaTien, int.Parse(diachi)));
                                    break;
                                case "Tap chi":
                                    this.Them(new TapChi(tenAnPham, nhaXuatBan, giaTien, diachi));
                                    break;
                                case "Bao":
                                    this.Them(new Bao(tenAnPham, nhaXuatBan, giaTien));
                                    break;
                                default:
                                    Console.WriteLine("Loai an pham khong hop le: " + loaiAnPham);
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Dong khong hop le: " + line);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Loi khi doc file: " + ex.Message);
            }
        }


    }
}

