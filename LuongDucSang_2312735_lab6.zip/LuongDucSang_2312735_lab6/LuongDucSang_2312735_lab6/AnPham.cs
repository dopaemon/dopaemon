﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuongDucSang_2312735_lab6
{
    interface IAnPham
    {
        string Ten { get; }
        float GiaTien { get; }
        string NhaXuatBan { get; }

    }
}
