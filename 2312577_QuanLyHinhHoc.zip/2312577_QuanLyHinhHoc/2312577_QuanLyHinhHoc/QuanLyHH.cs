﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _2312577_QuanLyHinhHoc.Class;

namespace _2312577_QuanLyHinhHoc
{
    public class QuanLyHH
    {
        private List<HinhHoc> dsHinhHoc;

        public QuanLyHH() {
            dsHinhHoc = new List<HinhHoc>();
        }
        public void ThemHinhHoc(HinhHoc hinhHoc)
        {
            dsHinhHoc.Add(hinhHoc);
        }
        public void XuatHinhHoc()
        {
            Console.WriteLine("Danh sach hinh hoc:");
            Console.WriteLine("==================");

            foreach (var hinh in dsHinhHoc)
            {
                if (hinh is HinhTron)
                {
                    HinhTron hinhTron = hinh as HinhTron;
                    Console.WriteLine($"Loai hinh: {hinhTron.Name}, Ban kinh: {hinhTron.BanKinh}");
                }
                else if (hinh is HinhVuong)
                {
                    HinhVuong hinhVuong = hinh as HinhVuong;
                    Console.WriteLine($"Loai hinh: {hinhVuong.Name}, Canh: {hinhVuong.Canh}");
                }
                else if (hinh is HinhCN)
                {
                    HinhCN hinhCN = hinh as HinhCN;
                    Console.WriteLine($"Loai hinh: {hinhCN.Name}, Chieu dai: {hinhCN.Canh}, Chieu rong: {hinhCN.Rong}");
                }
            }
        }

        public void NhapDanhSachHinhHocTuFile(string fileName)
        {
            try
            {
                using (StreamReader sr = new StreamReader(fileName))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] parts = line.Split(':');
                        if (parts.Length > 1)
                        {
                            string loaihinh = parts[0];
                            string canh = parts[1];
                            string rong = parts.Length > 2 ? parts[2] : null;

                            if (loaihinh == "HinhTron")
                            {
                                HinhHoc hinhHoc = new HinhTron(loaihinh, float.Parse(canh));
                                dsHinhHoc.Add(hinhHoc);
                            }
                            else if (loaihinh == "HinhVuong")
                            {
                                HinhHoc hinhHoc = new HinhVuong(loaihinh, float.Parse(canh));
                                dsHinhHoc.Add(hinhHoc);
                            }
                            else if (loaihinh == "HinhChuNhat")
                            {
                                HinhHoc hinhHoc = new HinhCN(loaihinh, float.Parse(rong), float.Parse(canh));
                                dsHinhHoc.Add(hinhHoc);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Da xay ra loi: {0}", ex.Message);
            }
        }
        public void XuatDienTichRiengCuaCacHinh()
        {
            Console.WriteLine("Dien tich rieng cua tung hinh:");
            Console.WriteLine("==============================");

            foreach (var hinh in dsHinhHoc)
            {
                if (hinh is HinhTron)
                {
                    HinhTron hinhTron = hinh as HinhTron;
                    Console.WriteLine($"Hinh tron - Ban kinh: {hinhTron.BanKinh}, Dien tich: {hinhTron.TinhDienTich()}");
                }
                else if (hinh is HinhVuong)
                {
                    HinhVuong hinhVuong = hinh as HinhVuong;
                    Console.WriteLine($"Hinh vuong - Canh: {hinhVuong.Canh}, Dien tich: {hinhVuong.TinhDienTich()}");
                }
                else if (hinh is HinhCN)
                {
                    HinhCN hinhCN = hinh as HinhCN;
                    Console.WriteLine($"Hinh chu nhat - Chieu dai: {hinhCN.Canh}, Chieu rong: {hinhCN.Rong}, Dien tich: {hinhCN.TinhDienTich()}");
                }
            }
        }

    }
}
