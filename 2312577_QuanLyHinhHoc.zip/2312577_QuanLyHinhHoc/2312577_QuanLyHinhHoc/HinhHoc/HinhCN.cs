﻿using System;

namespace _2312577_QuanLyHinhHoc.Class
{
    public class HinhCN : HinhHoc
    {
        public float Rong { get; set; }
        public float Canh { get; set; }
        public string Name { get; set; }

        public HinhCN() { }

        public HinhCN(string name, float rong, float canh)
        {
            this.Name = name;
            this.Rong = rong;
            this.Canh = canh;
        }

        public void NhapHCN()
        {
            Console.Write("Nhap chieu dai: ");
            Canh = float.Parse(Console.ReadLine());
            Console.Write("Nhap chieu rong: ");
            Rong = float.Parse(Console.ReadLine());
        }

        public float TinhDienTich()
        {
            return Canh * Rong;
        }
    }
}
