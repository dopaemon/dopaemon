﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2312577_QuanLyHinhHoc.Class
{
    public class HinhTron : HinhHoc
    {
        public string Name { get; }
        public float BanKinh { get; set; }

        public HinhTron() { }

        public HinhTron(string name, float banKinh)
        {
            this.Name = name;
            this.BanKinh = banKinh;
        }
        const float PI = 3.14F;
        public float TinhDienTich()
        {
            return ((PI * BanKinh) * (PI * BanKinh));
        }
    }
}
