﻿using _2312577_QuanLyHinhHoc.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2312577_QuanLyHinhHoc.Class
{
    public class LoaiHinh : HinhHoc
    {
        public LoaiHinh() { }
        public void Hinh(string loai)
        {
            switch (loai)
            {
                case "hinhtron":
                    break;
                case "hinhvuong":
                    break;
                case "hinhchunhat":
                    break;
                default:
                    break;
            }
        }
    }
}
