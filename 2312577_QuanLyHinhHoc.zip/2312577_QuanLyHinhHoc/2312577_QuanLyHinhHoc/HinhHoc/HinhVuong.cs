﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2312577_QuanLyHinhHoc.Class
{
    public class HinhVuong : HinhHoc
    {
        public string Name { get; }
        public float Canh { get; set; }

        public HinhVuong() { }

        public HinhVuong(string name, float canh)
        {
            this.Name = name;
            this.Canh = canh;
        }
        public void NhapHV()
        {
            Console.Write("Nhap canh: ");
            canh = float.Parse(Console.ReadLine());
        }
        public float TinhDienTich()
        {
            return Canh * Canh;
        }
    }
}
