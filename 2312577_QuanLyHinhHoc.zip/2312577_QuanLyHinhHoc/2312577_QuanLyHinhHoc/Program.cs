﻿using System;

namespace _2312577_QuanLyHinhHoc
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MenuQL menuQL = new MenuQL();   
            menuQL.ChayChuongTrinh();
        }
    }
}
