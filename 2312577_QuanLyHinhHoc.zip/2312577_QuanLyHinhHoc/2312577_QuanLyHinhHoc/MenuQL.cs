﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2312577_QuanLyHinhHoc
{
    internal class MenuQL
    {
        QuanLyHH qlhh = new QuanLyHH();
        public MenuQL() { }
        private void XuatMenu()
        {
            Console.Clear();
            Console.Write(@"============= Quan Ly Hinh Hoc =============
0. Thoat chuong trinh
1. Nhap danh sach tu File
2. Xuat danh sach hinh hoc
3. Tinh dien tich tat ca hinh
[1 - ?]: ");
        }

        private int ChonMenu()
        {
            string menu;
            menu = Console.ReadLine();
            return int.Parse(menu);
        }

        private void XuLyMenu(int menu)
        {
            switch (menu)
            {
                case 0:
                    Console.Clear();
                    Environment.Exit(0);
                    break;
                case 1:
                    Console.Clear();
                    Console.WriteLine("Nhap Hinh tu file");
                    qlhh.NhapDanhSachHinhHocTuFile("data.txt");
                    break;
                case 2:
                    Console.Clear();
                    Console.WriteLine("Xuat danh sach hinh hoc");
                    qlhh.XuatHinhHoc();
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("Tinh dien tich");
                    qlhh.XuatDienTichRiengCuaCacHinh();
                    break;
                default: break;
            }
            Console.WriteLine("Press Key To Continue !!!");
            Console.ReadKey();
        }

        public void ChayChuongTrinh()
        {
            int menu;
            while (true)
            {
                XuatMenu();
                menu = ChonMenu();
                XuLyMenu(menu);
            }
        }
    }
}
